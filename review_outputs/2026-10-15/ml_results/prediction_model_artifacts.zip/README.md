# Smart parking prediction model artifacts

Genuine TensorFlow/Keras models trained on the documented simulated dataset. These artifacts are for reproducibility and local inference, not validated real-world forecasts.

Each model has a compatible JSON manifest containing preprocessing parameters, feature schema, configuration, test metrics, versions, and SHA-256. All model inputs exclude RFID identifiers. Samples are synthetic. Latency is measured on the training server; no microcontroller inference or power measurement is included.
